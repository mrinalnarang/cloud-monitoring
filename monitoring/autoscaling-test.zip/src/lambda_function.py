import boto3
import json
import logging

# Initialize clients
autoscaling_client = boto3.client('autoscaling')
cloudwatch_client = boto3.client('cloudwatch')
cloudtrail_client = boto3.client('cloudtrail')

# Initialize the logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Log the entire received event for debugging
    logger.info(f"Received event: {json.dumps(event, indent=2)}")
    
    # Extract the Auto Scaling group name from the event
    try:
        detail = event.get('detail', {})
        request_parameters = detail.get('requestParameters', {})
        auto_scaling_group_name = request_parameters.get('autoScalingGroupName')
        
        # Check if the Auto Scaling group name is found
        if not auto_scaling_group_name:
            logger.error("Auto Scaling group name not found in event.")
            return {
                'statusCode': 400,
                'body': 'Error: Auto Scaling group name not found in event.'
            }
        
        # Log the extracted Auto Scaling group name
        logger.info(f"Auto Scaling group name: {auto_scaling_group_name}")
        
        # Get the current configuration of the Auto Scaling group
        response = autoscaling_client.describe_auto_scaling_groups(
            AutoScalingGroupNames=[auto_scaling_group_name]
        )
        
        if not response['AutoScalingGroups']:
            logger.error("Auto Scaling group not found.")
            return {
                'statusCode': 404,
                'body': 'Error: Auto Scaling group not found.'
            }

        auto_scaling_group = response['AutoScalingGroups'][0]
        max_size = auto_scaling_group['MaxSize']
        new_threshold = max_size * 0.8
        
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Internal server error: {str(e)}"
        }
    
    # Retrieve CloudWatch alarms related to the Auto Scaling group
    try:
        alarms = []
        next_token = None
        
        while True:
            if next_token:
                alarm_response = cloudwatch_client.describe_alarms(NextToken=next_token)
            else:
                alarm_response = cloudwatch_client.describe_alarms()
                
            alarms.extend(alarm_response['MetricAlarms'])
            next_token = alarm_response.get('NextToken')
            
            if not next_token:
                break
        
        filtered_alarms = [
            alarm for alarm in alarms 
            if any(d.get('Name') == 'AutoScalingGroupName' and d.get('Value') == auto_scaling_group_name for d in alarm.get('Dimensions', []))
        ]
        
        if not filtered_alarms:
            logger.info(f"No alarms found for Auto Scaling group: {auto_scaling_group_name}.")
            return {
                'statusCode': 404,
                'body': f"No alarms found for Auto Scaling group: {auto_scaling_group_name}."
            }
        
        for alarm in filtered_alarms:
            alarm_name = alarm['AlarmName']
            logger.info(f"Updating alarm {alarm_name} with new threshold {new_threshold}")
            
            update_params = {
                'AlarmName': alarm_name,
                'MetricName': alarm['MetricName'],
                'Namespace': alarm['Namespace'],
                'Statistic': alarm['Statistic'],
                'Period': alarm['Period'],
                'EvaluationPeriods': alarm['EvaluationPeriods'],
                'Threshold': new_threshold,
                'ComparisonOperator': alarm['ComparisonOperator'],
                'AlarmActions': alarm['AlarmActions'],
                'Dimensions': alarm['Dimensions']
            }
            
            if 'Unit' in alarm:
                update_params['Unit'] = alarm['Unit']
            
            cloudwatch_client.put_metric_alarm(**update_params)
            logger.info(f"Updated alarm {alarm_name} with new threshold {new_threshold}")
        
    except Exception as e:
        logger.error(f"Error retrieving or updating CloudWatch alarms: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Internal server error: {str(e)}"
        }
    
    return {
        'statusCode': 200,
        'body': 'Processing completed successfully.'
    }
